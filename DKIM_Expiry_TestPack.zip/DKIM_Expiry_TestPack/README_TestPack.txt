DKIM Expiry Test Pack  (for DKIM Bulk Signature Verifier v1.7.2)
https://github.com/jjrboucher/DKIM-Validator
Documentation licensed under CC BY 4.0. Test data is fictitious and uses
reserved example domains (RFC 2606).

Expected results below assume verification after 2026-11-05 and before 2027-08-03.

Key files (Mode 3 nomenclature format):
  rsa2026._domainkey.example.org.key          RSA 2048, h=sha256
  esp1._domainkey.mailer.example.net.key      RSA 1024, t=y (testing mode), n= note
  list2026._domainkey.lists.example.com.key   Ed25519

Run twice:
  python verify_dkim_bulk.py --no-gui --src DKIM_Expiry_TestPack --out out_default --mode 3
  python verify_dkim_bulk.py --no-gui --src DKIM_Expiry_TestPack --out out_strict  --mode 3 --strict-expiry

Signatures listed top (1) to bottom.

File                                    Signatures                                  Default    Strict
01_single_rsa_expired.eml               1 org RSA  x=2026-03-09 EXPIRED             PASS 1/1   FAIL (Expired)
02_single_ed25519_expired.eml           1 list Ed25519 x=2026-06-13 EXPIRED         PASS 1/1   FAIL (Expired)
03_single_rsa_not_expired_control.eml   1 org RSA  x=2027-11-04 VALID               PASS 1/1   PASS 1/1
04_single_expired_and_tampered.eml      1 org RSA  EXPIRED; amount 4,800->48,000    FAIL 0/1   FAIL 0/1
05_multi_2sig_one_expired.eml           1 ESP x=2026-09-16 EXPIRED                  PASS 2/2   PASS 1/2
                                        2 org no x=
06_multi_2sig_both_expired.eml          1 ESP x=2026-05-22 EXPIRED                  PASS 2/2   FAIL (Expired)
                                        2 org x=2026-06-03 EXPIRED
07_multi_3sig_mixed.eml                 1 list x=2027-10-28 VALID                   PASS 3/3   PASS 2/3
                                        2 ESP  x=2026-10-30 EXPIRED
                                        3 org  no x=
08_multi_only_expired_sig_verifies.eml  1 ESP x=2027-08-03 VALID - FAILS because    PASS 1/2   FAIL
                                          the Reply-To header it signed was altered
                                        2 org x=2026-08-13 EXPIRED - verifies

What to look at
- Main CSV: Signatures_Expired, and All_Signatures, which shows every signature's
  x= date and [EXPIRED]/[VALID] state (x=none when there is no expiry).
- dkim_signature_details.csv: Sig_Timestamp_UTC, Sig_Expiry_UTC, Expiry_Status per signature.
- keys_manifest.csv: Key_Bits (2048 / 1024 / 256), Key_Testing_Mode = YES and Key_Notes
  for the ESP key, Key_Hash_Algs = sha256 for example.org.
- Notes: "Key is in testing mode (t=y)" for ESP signatures.
- Sample 08: the only signature that still verifies is the expired one - Strict Expiry
  turns a cryptographically valid message into FAIL.
