DKIM Multi-Signature Test Pack  (for DKIM Bulk Signature Verifier v1.7.1)
https://github.com/jjrboucher/DKIM-Validator
Documentation licensed under CC BY 4.0. Test data is fictitious and uses
reserved example domains (RFC 2606) and documentation IP ranges (RFC 5737).

Each message carries THREE DKIM signatures, applied in this order (bottom to top):
  Sig 3  d=example.org         s=rsa2026   rsa-sha256      relaxed/relaxed  i=finance@example.org
  Sig 2  d=mailer.example.net  s=esp1      rsa-sha256      relaxed/simple   x= = t + 7 days
  Sig 1  d=lists.example.com   s=list2026  ed25519-sha256  relaxed/relaxed  signs List-Id too

Key files (nomenclature format, used by Mode 3 and as Mode 1 fallback):
  rsa2026._domainkey.example.org.key
  esp1._domainkey.mailer.example.net.key
  list2026._domainkey.lists.example.com.key

Run:  python verify_dkim_bulk.py --no-gui --src DKIM_MultiSig_TestPack --out test_out --mode 3

Expected results
File                                    Overall  Passed  Why
01_multi_dkim_all_pass.eml              PASS     3 of 3  Unmodified
02_multi_dkim_list_modified.eml         PASS     1 of 3  List added "[Procurement]" to Subject and a
                                                         footer, then re-signed: sigs 2 and 3 FAIL,
                                                         sig 1 (lists.example.com) PASSES
03_multi_dkim_body_tampered.eml         FAIL     0 of 3  Amount changed USD 12,450.00 -> 21,450.00
04_multi_dkim_LF_line_endings.eml       PASS     3 of 3  LF-only copy of 01; Line_Endings reports
                                                         "LF (normalised to CRLF)"
05_multi_dkim_from_header_altered.eml   FAIL     0 of 3  From changed example.org -> examp1e.org
                                                         (body hash MATCH, signature FAILED)

Notes
- After 2026-11-12 14:12:11 UTC, signature 2 reports EXPIRED. It still passes by
  default; with --strict-expiry it reports FAIL (Expired). Overall results for
  01/02/04 are unchanged because other signatures still pass.
- Mode 2 (sidecar) is not suited to these files: one key cannot verify all three signatures.
- In Mode 1 the example domains do not resolve, so keys come from the fallback files;
  Notes will record the DNS failures. keys/ and keys_manifest.csv in the output will
  contain the three keys.
